-- Шрифты с поддержкой кириллицы
surface.CreateFont("Bahnschrift_Cyrillic_30", {
    font = "Bahnschrift",
    extended = true,
    size = 30,
    weight = 700,
    antialias = true
})

surface.CreateFont("Bahnschrift_Cyrillic_22", {
    font = "Bahnschrift",
    extended = true,
    size = 22,
    weight = 500,
    antialias = true
})

surface.CreateFont("Bahnschrift_Cyrillic_18", {
    font = "Bahnschrift",
    extended = true,
    size = 18,
    weight = 400,
    antialias = true
})

surface.CreateFont("Bahnschrift_Cyrillic_16", {
    font = "Bahnschrift",
    extended = true,
    size = 16,
    weight = 300,
    antialias = true
})

surface.CreateFont("Bahnschrift_Cyrillic_14", {
    font = "Bahnschrift",
    extended = true,
    size = 14,
    weight = 300,
    antialias = true
})

local activeNotifications = {}
local notificationQueue = {}

net.Receive("AdminNotifySound", function()
    local soundPath = net.ReadString()
    surface.PlaySound(soundPath)
end)

net.Receive("AdminNotifyAdvanced", function()
    local title = net.ReadString()
    local message = net.ReadString()
    local reason = net.ReadString()
    local color = net.ReadColor()
    local icon = net.ReadString()
    local duration = net.ReadFloat()

    table.insert(notificationQueue, {
        title = title,
        message = message,
        reason = reason,
        color = color,
        icon = Material(icon),
        duration = duration,
        startTime = CurTime(),
        yPos = -100
    })
    
    if #activeNotifications == 0 then
        ShowNextNotification()
    end
end)

function ShowNextNotification()
    if #notificationQueue == 0 then return end
    
    local notifData = table.remove(notificationQueue, 1)
    notifData.id = "notif_" .. CurTime() .. math.random(1000, 9999)

    local panelWidth = ScrW() * 0.25
    local panelHeight = 90
    
    local panel = vgui.Create("DPanel")
    panel:SetSize(panelWidth, panelHeight)
    panel:SetPos(ScrW() - panelWidth - 20, notifData.yPos)
    panel:SetAlpha(0)
    panel:SetMouseInputEnabled(false)

    panel:MoveTo(ScrW() - panelWidth - 20, 20, 0.5, 0, 0.3, function()
        timer.Simple(notifData.duration, function()
            if IsValid(panel) then
                panel:MoveTo(ScrW() + 20, 20, 0.5, 0, 0.3, function()
                    panel:Remove()
                    table.RemoveByValue(activeNotifications, notifData.id)
                    ShowNextNotification()
                end)
            end
        end)
    end)
    
    panel:AlphaTo(255, 0.4, 0)

    panel.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(20, 20, 20, 230))
        
        draw.RoundedBoxEx(8, 0, 0, 6, h, notifData.color, true, false, true, false)
        
        if notifData.icon then
            surface.SetDrawColor(255, 255, 255, 200)
            surface.SetMaterial(notifData.icon)
            surface.DrawTexturedRect(15, h/2 - 15, 30, 30)
        end
        
        local textX = notifData.icon and 55 or 15
        
        draw.SimpleText(notifData.title, "Bahnschrift_Cyrillic_22", textX, 15, notifData.color, TEXT_ALIGN_LEFT)
        
        local truncatedMessage = notifData.message
        if string.len(truncatedMessage) > 40 then
            truncatedMessage = string.sub(truncatedMessage, 1, 37) .. "..."
        end
        draw.SimpleText(truncatedMessage, "Bahnschrift_Cyrillic_16", textX, 40, Color(220, 220, 220), TEXT_ALIGN_LEFT)
        
        draw.SimpleText("От: " .. notifData.reason, "Bahnschrift_Cyrillic_14", textX, 62, Color(160, 160, 160), TEXT_ALIGN_LEFT)
        
        local timeLeft = (notifData.startTime + notifData.duration) - CurTime()
        if timeLeft > 0 then
            local progress = (timeLeft / notifData.duration)
            local barWidth = (w - 30) * progress
            draw.RoundedBox(2, 15, h - 6, barWidth, 2, notifData.color)
        end
    end
    
    activeNotifications[notifData.id] = true
    notifData.panel = panel
end

hook.Add("Think", "AdminNotificationsThink", function()
    local yOffset = 20
    
    for _, notifData in pairs(notificationQueue) do
        if notifData.panel and IsValid(notifData.panel) then
            local targetY = yOffset
            local currentX, currentY = notifData.panel:GetPos()
            
            if currentY != targetY then
                notifData.panel:MoveTo(ScrW() - notifData.panel:GetWide() - 20, targetY, 0.2)
            end
            
            yOffset = yOffset + notifData.panel:GetTall() + 10
        end
    end
end)

hook.Add("ShutDown", "CleanupNotifications", function()
    for _, notifData in pairs(notificationQueue) do
        if notifData.panel and IsValid(notifData.panel) then
            notifData.panel:Remove()
        end
    end
    notificationQueue = {}
    activeNotifications = {}
end)