-- Система админ-уведомлений с звуком и причиной
util.AddNetworkString("AdminNotifyAdvanced")
util.AddNetworkString("AdminNotifySound")

-- Загрузка шрифта на клиент
resource.AddSingleFile("resource/fonts/bahnschrift.ttf")

-- Стандартные типы уведомлений
local NOTIFY_TYPES = {
    ["restart"] = {
        title = "РЕСТАРТ СЕРВЕРА",
        color = Color(231, 76, 60), -- Красный
        sound = "airstrikecallin.ogg",
        icon = "icon16/arrow_refresh.png"
    },
    ["rules"] = {
        title = "ОБНОВЛЕНИЕ ПРАВИЛ",
        color = Color(52, 152, 219), -- Синий
        sound = "airstrikecallin.ogg",
        icon = "icon16/book_edit.png"
    },
    ["event"] = {
        title = "ИВЕНТ",
        color = Color(46, 204, 113), -- Зеленый
        sound = "pipes.mp3",
        icon = "icon16/calendar.png"
    },
    ["warning"] = {
        title = "ПРЕДУПРЕЖДЕНИЕ",
        color = Color(230, 126, 34), -- Оранжевый
        sound = "s_crush_m.wav",
        icon = "icon16/error.png"
    },
    ["info"] = {
        title = "ИНФОРМАЦИЯ",
        color = Color(155, 89, 182), -- Фиолетовый
        sound = "airstrikecallin.ogg",
        icon = "icon16/information.png"
    },
    ["maintenance"] = {
        title = "ТЕХНИЧЕСКИЕ РАБОТЫ",
        color = Color(241, 196, 15), -- Желтый
        sound = "airstrikecallin.ogg",
        icon = "icon16/wrench.png"
    }
}

-- Стандартные тексты для быстрого использования
local STANDARD_MESSAGES = {
    ["restart"] = {
        "Сервер будет перезагружен",
        "Плановый рестарт через 5 минут.",
        "Экстренный рестарт из-за технических проблем."
    },
    ["warning"] = {
        "На сервере запрещен HEXAGON.LUA + Kefir.vip + Dobroware + ZOVGAME",-- poshalko dlya bezmamnyh (ты)
        "ВАМ ПИЗДА НАХУЙ",
        "ВЫ СЫНОВЯ ШЛЮХ НАХУЙ"
    },
    ["event"] = {
        "Сегодня ивент",
        "ДА НАЧНЕТСЯ ЖАРА!",
        "Еженедельный ивент"
    }
}

-- Основная функция отправки уведомления
function SendAdminNotification(ply, notifyType, message, reason, duration)
    duration = duration or 7
    
    -- Определяем тип уведомления
    local notifyData = NOTIFY_TYPES[notifyType] or NOTIFY_TYPES["info"]
    
    -- Отправляем звук
    net.Start("AdminNotifySound")
        net.WriteString(notifyData.sound)
    net.Broadcast()
    
    -- Отправляем уведомление
    net.Start("AdminNotifyAdvanced")
        net.WriteString(notifyData.title)
        net.WriteString(message)
        net.WriteString(reason or "Администрация сервера")
        net.WriteColor(notifyData.color)
        net.WriteString(notifyData.icon)
        net.WriteFloat(duration)
    if ply then
        net.Send(ply)
    else
        net.Broadcast()
    end
    
    -- Логирование в консоль сервера
    print(string.format("[ADMIN-NOTIFY] %s: %s (Причина: %s)", notifyData.title, message, reason or "Не указана"))
end

-- Консольные команды для админов
concommand.Add("notify_restart", function(ply, cmd, args)
    if not ply:IsAdmin() then return end
    local reason = table.concat(args, " ") or "Сервер"
    SendAdminNotification(nil, "restart", 
        "Сервер будет перезагружен. restart", 
        reason, 10)
end)

concommand.Add("notify_warning", function(ply, cmd, args)
    if not ply:IsAdmin() then return end
    local message = table.concat(args, " ") or "ЧИТЕРЫ ПОГАНЫЕ!"
    SendAdminNotification(nil, "warning", message, ply:Nick(), 8)
end)

concommand.Add("notify_event", function(ply, cmd, args)
    if not ply:IsAdmin() then return end
    local eventName = table.concat(args, " ") or "D A U N"
    SendAdminNotification(nil, "event", 
        string.format("Что ивент? Да начинается тот самый нахуй ивент....", eventName), 
        "Администрация", 8)
end)

concommand.Add("notify_custom", function(ply, cmd, args)
    if not ply:IsAdmin() then return end
    if #args < 2 then
        ply:ChatPrint("Использование: notify_custom <тип> <сообщение> [причина]")
        return
    end
    
    local notifyType = args[1]
    local message = args[2]
    local reason = args[3] or ply:Nick()
    
    SendAdminNotification(nil, notifyType, message, reason, 8)
end)

-- Функция для использования в других скриптах
function AdminNotify(notifyType, message, reason, duration)
    SendAdminNotification(nil, notifyType, message, reason, duration)
end

-- Автоматические уведомления при запуске
timer.Simple(30, function()
    SendAdminNotification(nil, "info", 
        "Добро пожаловать на сервер! (заходи не бойся, выходи не плачь...)", 
        "Автоматическое сообщение", 6)
end)