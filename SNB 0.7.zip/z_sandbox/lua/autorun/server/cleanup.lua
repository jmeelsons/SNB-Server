local Enabled = true
local CleanupInterval = 300 -- Интервал в секундах (измените при необходимости)
local WarningTime = 15 -- За сколько секунд предупреждать

local function IsZBattleMode()
    return engine.ActiveGamemode() == "zbattle" or GAMEMODE and GAMEMODE.Name == "zbattle"
end

local function IsPlayerAdmin(ply)
    if not IsValid(ply) then return false end
    return ply:IsAdmin() or ply:IsSuperAdmin() or ply:CheckGroup("admin")
end

local function SendChatMessage(ply, text, color)
    if IsValid(ply) then
        ply:ChatPrint(text)
    else
        for _, v in ipairs(player.GetAll()) do
            v:ChatPrint(text)
        end
    end
end

local function SendColorMessage(ply, color, text)
    if IsValid(ply) then
        ply:SendLua(string.format("chat.AddText(Color(%d, %d, %d), %s)", 
            color.r, color.g, color.b, string.format("%q", text)))
    else
        for _, v in ipairs(player.GetAll()) do
            v:SendLua(string.format("chat.AddText(Color(%d, %d, %d), %s)", 
                color.r, color.g, color.b, string.format("%q", text)))
        end
    end
end

local function AutoCleanup()
    if not Enabled then return end
    
    if IsZBattleMode() then
        print("[AutoCleanup] Очистка отключена: активен игровой режим zbattle")
        return
    end
    
    print("[AutoCleanup] Начинаю процесс очистки...")
    
    SendColorMessage(nil, Color(255, 50, 50), "ВНИМАНИЕ: Очистка сервера через " .. WarningTime .. " секунд!")
    SendColorMessage(nil, Color(255, 100, 100), "Сохраняйте все важное!")
    
        timer.Simple(WarningTime, function()
        if not Enabled then return end
        
        if IsZBattleMode() then
            SendColorMessage(nil, Color(255, 150, 50), "Очистка отменена: активен режим zbattle")
            print("[AutoCleanup] Очистка отменена: активен игровой режим zbattle")
            return
        end
        
        local playersBefore = {}
        for _, ply in ipairs(player.GetAll()) do
            playersBefore[ply:SteamID()] = true
        end

        game.CleanUpMap(false)
        
        for _, ply in ipairs(player.GetAll()) do
            if not playersBefore[ply:SteamID()] then
                ply:Spawn()
            end
        end
        
        SendColorMessage(nil, Color(50, 255, 50), "Сервер успешно очищен!")
        print("[AutoCleanup] Сервер очищен в " .. os.date("%H:%M:%S"))
        
        collectgarbage("collect")
    end)
end

timer.Create("AutoCleanupTimer", CleanupInterval, 0, function()
    if IsZBattleMode() then
        print("[AutoCleanup] Таймер пропущен: активен игровой режим zbattle")
        return
    end
    
    if Enabled then
        AutoCleanup()
    end
end)

concommand.Add("autocleanup_toggle", function(ply, cmd, args)
    if IsValid(ply) and not IsPlayerAdmin(ply) then
        SendChatMessage(ply, "У вас нет прав администратора!", Color(255, 50, 50))
        return
    end
    
    if IsZBattleMode() then
        local msg = "Автоочистка отключена в режиме zbattle"
        if IsValid(ply) then
            SendChatMessage(ply, msg)
        else
            print("[AutoCleanup] " .. msg)
        end
        return
    end
    
    Enabled = not Enabled
    
    if Enabled then
        timer.Start("AutoCleanupTimer")
        local msg = "[AutoCleanup] Включено"
        if IsValid(ply) then
            msg = msg .. " администратором " .. ply:Name()
        end
        print(msg)
        SendColorMessage(nil, Color(50, 150, 255), "Автоочистка включена")
    else
        timer.Stop("AutoCleanupTimer")
        local msg = "[AutoCleanup] Выключено"
        if IsValid(ply) then
            msg = msg .. " администратором " .. ply:Name()
        end
        print(msg)
        SendColorMessage(nil, Color(255, 150, 50), "Автоочистка выключена")
    end
    
    if IsValid(ply) then
        SendChatMessage(ply, "Автоочистка " .. (Enabled and "включена" or "выключена"))
    end
end)

concommand.Add("autocleanup_status", function(ply)
    if IsValid(ply) and not IsPlayerAdmin(ply) then
        SendChatMessage(ply, "У вас нет прав администратора!", Color(255, 50, 50))
        return
    end
    
    local status = Enabled and "ВКЛЮЧЕНА" or "ВЫКЛЮЧЕНА"
    local timeLeft = "Н/Д"
    local modeStatus = IsZBattleMode() and " (отключено в zbattle)" or ""
    
    if Enabled and not IsZBattleMode() then
        timeLeft = math.Round(timer.TimeLeft("AutoCleanupTimer") or 0) .. " сек"
    end
    
    local message = string.format("Статус автоочистки: %s%s\nДо следующей очистки: %s", 
        status, modeStatus, timeLeft)
    
    if IsValid(ply) then
        SendChatMessage(ply, message)
    else
        print("[AutoCleanup] " .. message)
    end
end)

concommand.Add("autocleanup_now", function(ply, cmd, args)
    if IsValid(ply) and not IsPlayerAdmin(ply) then
        SendChatMessage(ply, "У вас нет прав администратора!", Color(255, 50, 50))
        return
    end
    
    if IsZBattleMode() then
        local msg = "Очистка отключена в режиме zbattle"
        if IsValid(ply) then
            SendChatMessage(ply, msg)
        else
            print("[AutoCleanup] " .. msg)
        end
        return
    end
    
    if IsValid(ply) then
        print("[AutoCleanup] Принудительная очистка инициирована администратором " .. ply:Name())
    else
        print("[AutoCleanup] Принудительная очистка инициирована из консоли")
    end
    
    AutoCleanup()
end)

hook.Add("Initialize", "AutoCleanupInit", function()
    if not IsZBattleMode() then
        timer.Start("AutoCleanupTimer")
        print("[AutoCleanup] Система инициализирована, интервал: " .. CleanupInterval .. " секунд")
    else
        print("[AutoCleanup] Система отключена: активен игровой режим zbattle")
    end
end)

hook.Add("PlayerInitialSpawn", "AutoCleanupWelcome", function(ply)
    timer.Simple(5, function()
        if IsValid(ply) then
            if not IsZBattleMode() and Enabled then
                SendColorMessage(ply, Color(100, 200, 255), 
                    "На сервере работает автоочистка каждые " .. CleanupInterval .. " секунд")
                SendColorMessage(ply, Color(150, 150, 150), 
                    "Администраторы могут управлять через команду autocleanup_toggle")
            end
        end
    end)
end)

hook.Add("ShutDown", "AutoCleanupShutdown", function()
    if timer.Exists("AutoCleanupTimer") then
        timer.Remove("AutoCleanupTimer")
    end
end)

hook.Add("OnGamemodeLoaded", "AutoCleanupGamemodeCheck", function()
    if IsZBattleMode() then
        print("[AutoCleanup] Обнаружен режим zbattle, отключаю автоочистку")
        timer.Stop("AutoCleanupTimer")
        Enabled = false
    else
        print("[AutoCleanup] Режим не zbattle, автоочистка доступна")
    end
end)

print("[AutoCleanup] Система загружена успешно! Текущий режим: " .. (IsZBattleMode() and "zbattle (отключено)" or "не zbattle"))