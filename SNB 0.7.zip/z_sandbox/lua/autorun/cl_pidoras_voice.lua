hook.Add("Initialize", "suka", function()
    GM = GM or GAMEMODE

    function GM:PlayerStartVoice(ply)
        return
    end
end)

local cv_mode = CreateClientConVar("ebg_voice", "0", true, false)

local z, m = 90, 50
local xx = 5
local ofx, ofy, vx, vy, lasty, lastp = 0, 0, 0, 0, 0, 0

local mats = {
    boykis_active = Material("localr/boykis.png"),
    boykis_idle = Material("localr/boykis1.png"),
    default = Material("ebg/voice1.png"),
    furry_voice = Material("snb/protogen_voice.png"),
    human_voice = Material("snb/human_voice.png")
}

hook.Add("HUDPaint", "ZOVZVZVZVZVZALUPAPENISSEX", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    
    if not ply:Alive() then
        return
    end
    
    local ca = ply:EyeAngles()
    local mode = cv_mode:GetInt()
    
    local dy = math.AngleDifference(ca.yaw, lasty)
    local dp = -math.AngleDifference(ca.pitch, lastp)
    
    local tx = math.Clamp(dy * 45.5, -60, 60)
    local ty = math.Clamp(dp * 32.5, -60, 60)
    
    lasty = ca.yaw
    lastp = ca.pitch
    
    vx = (vx + (tx - ofx) * 0.05) * 0.9 
    vy = (vy + (ty - ofy) * 0.05) * 0.9
    ofx = ofx + vx
    ofy = ofy + vy

    if ply:IsSpeaking() then
        local vol = ply:VoiceVolume()
        xx = math.Approach(xx, vol * 35, FrameTime() * 90)
        
        local squash = vol * 1 -- 100%
        local ns_w = z * (1 + vol * 2.5) * (1 + squash)
        local ns_h = z * (1 + vol * 2.5) * (1 - squash)
        
        local bx = math.sin(CurTime() * 48) * xx
        local by = math.cos(CurTime() * 4.2) * xx
        
        local x = ScrW() / 2 + bx + ofx - ns_w / 2
        local y = ScrH() - m + by + ofy - ns_h - (z * 0.2) 
        
        if mode == 1 then
            if vol > 0.01 then
                surface.SetMaterial(mats.boykis_active)
            else
                surface.SetMaterial(mats.boykis_idle)
            end
        else
            if ply.PlayerClassName == "furry" then
                surface.SetMaterial(mats.furry_voice)
            else
                surface.SetMaterial(mats.human_voice)
            end
        end
        
        surface.SetDrawColor(255, 255, 255, 255)
        
        local rot = math.Clamp((dy * 0.3 + dp * 0.2) * 0.5, -12, 12)
        
        cam.Start2D()
            local mx = Matrix()
            mx:Translate(Vector(x + ns_w/2, y + ns_h/2, 0))
            mx:Rotate(Angle(0, 0, rot))
            mx:Translate(Vector(-ns_w/2, -ns_h/2, 0))
            cam.PushModelMatrix(mx)
                surface.DrawTexturedRect(0, 0, ns_w, ns_h)
            cam.PopModelMatrix()
        cam.End2D()
    else
        xx = math.Approach(xx, 22, FrameTime() * 100)
    end
end)