local VOICE_MAT = Material("hud/voice/mic.png")
local VOICE_WIDGET_MAT = Material("hud/voice/mic_mover.png", "smooth mips")
local RADIO_VOICE_MAT = Material("hud/voice/radio.png")
local RADIO_VOICE_WIDGET_MAT = Material("hud/voice/radio_mover.png", "smooth mips")

local playerVoiceAlpha = {}

local function IsPlayerTalkingInRadio(ply)
    return ply:GetNWBool("Radio.MainSpeaking", false)
end

-- Хук для отрисовки иконок голоса
hook.Add("PostDrawTranslucentRenderables", "TalkIcons_Draw", function()
    for _, pPlayer in pairs(player.GetAll()) do
        if not IsValid(pPlayer) then continue end
        if not pPlayer:Alive() then continue end
        if pPlayer:GetNoDraw() then continue end
        if pPlayer == LocalPlayer() then
               continue
        end
        

        local volume = pPlayer:VoiceVolume()
        
        if not playerVoiceAlpha[pPlayer] then
            playerVoiceAlpha[pPlayer] = 0
        end
        
        playerVoiceAlpha[pPlayer] = Lerp(FrameTime() * 6, playerVoiceAlpha[pPlayer], (volume > 0.01) and 255 or 0)
        
        if playerVoiceAlpha[pPlayer] < 0.01 then
            playerVoiceAlpha[pPlayer] = 0
            continue
        end

        local pos = pPlayer:GetPos() + Vector(0, 0, pPlayer:GetModelRadius() + 15)
        local attachment = pPlayer:GetAttachment(pPlayer:LookupAttachment("eyes"))
        
        if attachment then
            pos = attachment.Pos + Vector(0, 0, 15)
        end

        local cColor = Color(220, 220, 220, playerVoiceAlpha[pPlayer])
        local bTalkingInRadio = IsPlayerTalkingInRadio(pPlayer)
        
        if bTalkingInRadio then
            cColor = Color(150, 185, 200, playerVoiceAlpha[pPlayer])
            
            render.SetMaterial(RADIO_VOICE_WIDGET_MAT)
            render.DrawSprite(pos, (7 + 0.25) * volume, 7 + 0.25, Color(0, 0, 0, 50 * (playerVoiceAlpha[pPlayer] / 255)))
            
            render.SetMaterial(RADIO_VOICE_WIDGET_MAT)
            render.DrawSprite(pos, 7 * volume, 7, Color(cColor.r, cColor.g, cColor.b, playerVoiceAlpha[pPlayer]))
            
            render.SetMaterial(RADIO_VOICE_MAT)
            render.DrawSprite(pos, 6 + 0.25, 6 + 0.25, Color(0, 0, 0, 50 * (playerVoiceAlpha[pPlayer] / 255)))
            
            render.SetMaterial(RADIO_VOICE_MAT)
            render.DrawSprite(pos, 6, 6, Color(cColor.r, cColor.g, cColor.b, playerVoiceAlpha[pPlayer]))
        else

            render.SetMaterial(VOICE_WIDGET_MAT)
            render.DrawSprite(pos, 7 + 0.25, (7 + 0.25) * volume, Color(0, 0, 0, 50 * (playerVoiceAlpha[pPlayer] / 255)))
            
            render.SetMaterial(VOICE_WIDGET_MAT)
            render.DrawSprite(pos, 7, 7 * volume, Color(cColor.r, cColor.g, cColor.b, playerVoiceAlpha[pPlayer]))
            
            render.SetMaterial(VOICE_MAT)
            render.DrawSprite(pos, 6 + 0.25, 6 + 0.25, Color(0, 0, 0, 50 * (playerVoiceAlpha[pPlayer] / 255)))

            render.SetMaterial(VOICE_MAT)
            render.DrawSprite(pos, 6, 6, Color(cColor.r, cColor.g, cColor.b, playerVoiceAlpha[pPlayer]))
        end
    end
end)

hook.Add("PlayerDisconnected", "TalkIcons_Cleanup", function(ply)
    if playerVoiceAlpha[ply] then
        playerVoiceAlpha[ply] = nil
    end
end)