-- Сделай UI супер компактно и чуть сгругленно
local pickupHistory = {}
local typeState = {}

local FONT = "HomigradFont"
local COLOR_BG = Color(0, 0, 0, 180)
local COLOR_OUTLINE_DEF = Color(255, 0, 0, 255)
local COLOR_TEXT_DEF = Color(255, 255, 255, 255)
local COLOR_LOSS = Color(255, 80, 80, 255)
local DISPLAY_TIME = 4
local TYPE_SPEED = 20
local MAX_WIDTH = ScreenScale(150)
local PADDING = ScreenScale(2)
local SPACING = ScreenScale(1)
local CORNER_RADIUS = 3

-- Цвета из темы
local function GetAccentColor()
    return hg and hg.theme and hg.theme.c and hg.theme.c.accent or COLOR_OUTLINE_DEF
end

local function GetTextColor()
    return hg and hg.theme and hg.theme.c and hg.theme.c.text or COLOR_TEXT_DEF
end

-- Утилиты
local function LerpColor(fraction, from, to)
    return Color(
        Lerp(fraction, from.r, to.r),
        Lerp(fraction, from.g, to.g),
        Lerp(fraction, from.b, to.b),
        Lerp(fraction, from.a, to.a)
    )
end

-- Добавление уведомления
function hg.AddPickupNotification(text, isLoss)
    pickupHistory = pickupHistory or {}
    typeState = typeState or {}
    
    local id = tostring(CurTime()) .. "_" .. math.random(1, 1000)
    table.insert(pickupHistory, {
        text = text,
        time = CurTime(),
        id = id,
        isLoss = isLoss or false,
        offsetY = 0,
        slideProgress = 0
    })
    typeState[id] = { smoothW = 0, alpha = 0 }
end

-- Хуки для предметов
hook.Add("HUDItemPickedUp", "HomigradPickup_Item", function(itemName)
    if not IsValid(LocalPlayer()) or not LocalPlayer():Alive() then return end
    hg.AddPickupNotification(language.GetPhrase(itemName))
    return true
end)

hook.Add("HUDAmmoPickedUp", "HomigradPickup_Ammo", function(itemName, amount)
    if not IsValid(LocalPlayer()) or not LocalPlayer():Alive() then return end
    hg.AddPickupNotification(amount .. " " .. language.GetPhrase(itemName))
    return true
end)

hook.Add("HUDWeaponPickedUp", "HomigradPickup_Weapon", function(wep)
    if not IsValid(LocalPlayer()) or not LocalPlayer():Alive() then return end
    if IsValid(wep) and wep:GetClass() ~= "weapon_hands_sh" then
        hg.AddPickupNotification(language.GetPhrase(wep:GetPrintName()))
    end
    return true
end)

net.Receive("HG_WeaponDrop", function()
    local wep = net.ReadEntity()
    if IsValid(wep) and wep:GetClass() ~= "weapon_hands_sh" then
        hg.AddPickupNotification(language.GetPhrase(wep:GetPrintName()), true)
    end
end)

-- Основной рендер
hook.Add("HUDPaint", "HomigradPickup_Paint", function()
    pickupHistory = pickupHistory or {}
    typeState = typeState or {}
    
    if not pickupHistory or #pickupHistory == 0 then return end
    
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end
    if ply.organism and ply.organism.otrub then return end
    
    local scrW, scrH = ScrW(), ScrH()
    local startX = scrW - ScreenScale(10)
    local startY = scrH * 0.4
    local accent = GetAccentColor()
    local textColor = GetTextColor()
    
    surface.SetFont(FONT)
    
    -- Лимит отображаемых уведомлений
    local maxNotifications = 5
    local displayedCount = 0
    
    for i = #pickupHistory, 1, -1 do
        if displayedCount >= maxNotifications then break end
        
        local pickup = pickupHistory[i]
        if not pickup then continue end
        
        local state = typeState[pickup.id]
        if not state then
            table.remove(pickupHistory, i)
            continue
        end
        
        local elapsed = CurTime() - pickup.time
        
        -- Анимация появления (слайд справа)
        pickup.slideProgress = Lerp(FrameTime() * 8, pickup.slideProgress or 0, 1)
        local slideOffset = (1 - pickup.slideProgress) * ScreenScale(50)
        
        -- Расчет анимации
        local typeDuration = #pickup.text / TYPE_SPEED
        local fadeIn = math.min(elapsed, 0.2)
        local typeIn = math.max(0, elapsed - 0.2)
        local typeProgress = math.min(typeIn / typeDuration, 1)
        local idleTime = elapsed - 0.2 - typeDuration
        local fadeOut = math.max(0, idleTime - DISPLAY_TIME)
        
        -- Удаление завершенных анимаций
        if fadeOut > 0.5 then
            table.remove(pickupHistory, i)
            typeState[pickup.id] = nil
            continue
        end
        
        -- Расчет альфы
        local alpha = 255
        if fadeIn < 0.2 then
            alpha = (fadeIn / 0.2) * 255
        elseif fadeOut > 0 then
            alpha = 255 * (1 - math.min(fadeOut / 0.5, 1))
        end
        
        -- Отображаемый текст
        local visibleChars = math.floor(typeProgress * #pickup.text)
        local displayText = string.sub(pickup.text, 1, visibleChars)
        
        -- Если текст слишком длинный, обрезаем его
        if #pickup.text > 30 then
            displayText = string.sub(pickup.text, 1, 27) .. "..."
        end
        
        -- Размеры
        local tw, th = surface.GetTextSize(displayText)
        local targetW = math.min(tw + PADDING * 2, MAX_WIDTH)
        state.smoothW = Lerp(FrameTime() * 15, state.smoothW or 0, targetW)
        state.alpha = Lerp(FrameTime() * 12, state.alpha or 0, alpha)
        
        local boxW = state.smoothW
        local boxH = th + PADDING * 0.8
        local posX = startX - boxW + slideOffset
        local posY = startY + (displayedCount * (boxH + SPACING))
        
        -- Плавное смещение вниз
        pickup.offsetY = Lerp(FrameTime() * 8, pickup.offsetY or 0, 0)
        posY = posY + pickup.offsetY
        
        -- Цвета с альфой
        local bgColor = ColorAlpha(COLOR_BG, state.alpha * 0.9)
        local outlineColor = pickup.isLoss and ColorAlpha(COLOR_LOSS, state.alpha) or ColorAlpha(accent, state.alpha)
        local textFinalColor = ColorAlpha(textColor, state.alpha)
        
        -- Рисование с закругленными углами
        draw.RoundedBox(CORNER_RADIUS, posX, posY, boxW, boxH, bgColor)
        
        -- Тонкая обводка
        surface.SetDrawColor(outlineColor)
        surface.DrawOutlinedRect(posX, posY, boxW, boxH, 1)
        
        -- Тень для текста
        draw.SimpleText(displayText, FONT, posX + PADDING + 1, posY + boxH/2 + 1, 
                       Color(0, 0, 0, state.alpha * 0.7), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Основной текст
        draw.SimpleText(displayText, FONT, posX + PADDING, posY + boxH/2, 
                       textFinalColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Иконка для потери/получения
        if typeProgress == 1 then
            local icon = pickup.isLoss and "" or ""
            local iconColor = pickup.isLoss and ColorAlpha(COLOR_LOSS, state.alpha) or ColorAlpha(accent, state.alpha)
            draw.SimpleText(icon, FONT, posX + boxW - PADDING, posY + boxH/2, 
                           iconColor, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end
        
        displayedCount = displayedCount + 1
    end
end)

-- Очистка старых уведомлений
timer.Create("HomigradPickup_Cleanup", 1, 0, function()
    pickupHistory = pickupHistory or {}
    typeState = typeState or {}
    
    local curTime = CurTime()
    for i = #pickupHistory, 1, -1 do
        local pickup = pickupHistory[i]
        if pickup and curTime - pickup.time > DISPLAY_TIME + 2 then
            table.remove(pickupHistory, i)
            if pickup.id then
                typeState[pickup.id] = nil
            end
        end
    end
end)

-- Инициализация при загрузке файла
if not hg then hg = {} end
hg.AddPickupNotification = hg.AddPickupNotification or function(text, isLoss)
    -- Fallback функция
    print("[Homigrad] Pickup: " .. text)
end

print("[Homigrad] Pickup HUD loaded successfully")