-- Add this to addons/homigrad/lua/homigrad/hud/cl_dobroshield.lua or adapt to your file.

if SERVER then return end -- Ensure this runs client-side only

-- Create the font (Bahnschrift or fallback)
surface.CreateFont("ZSandboxFont", {
    font = "Bahnschrift", -- Use Bahnschrift if available
    extended = false,
    size = 24, -- Adjust size as needed
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    additive = false,
    shadow = false
})

-- Hook into HudPaint to draw on the HUD
hook.Add("HUDPaint", "ZSandboxHUD", function()
    -- Set the font
    surface.SetFont("ZSandboxFont")
    
    -- Text parts
    local zText = "SNB"
    local restText = "-RU"
    local fullText = zText .. restText
    
    -- Get text sizes
    local zWidth, textHeight = surface.GetTextSize(zText)
    local restWidth, _ = surface.GetTextSize(restText)
    local fullWidth = zWidth + restWidth
    
    -- Calculate positions: Top right corner, with some margin
    local scrW, scrH = ScrW(), ScrH()
    local x = scrW - fullWidth - 0  -- 20 pixels from right edge
    local y = 0  -- 20 pixels from top edge
    
    -- Main text: Z in red
    surface.SetTextColor(255, 0, 0)  -- Red for Z
    surface.SetTextPos(x, y)
    surface.DrawText(zText)
    
    -- Rest in white
    surface.SetTextColor(255, 255, 255)  -- White for the rest
    surface.SetTextPos(x + zWidth, y)
    surface.DrawText(restText)
end)
